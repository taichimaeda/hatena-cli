from flatdict import FlatDict
from typing import Optional
from typing_extensions import Annotated
from pathlib import Path
from rich import print
import typer

from .config import get_config, init_config, set_config
from .auth import init_auth
from .api import upload_entry, update_entry, delete_entry
from . import __version__

app = typer.Typer()


@app.callback()
def main(
    version: Annotated[
        Optional[bool], typer.Option(help="Show the CLI version.", is_eager=True)
    ] = None,
):
    """
    CLI utility for Hatena Blog.
    """
    if version:
        print(f"Hatena Blog CLI Version: {__version__}")
        raise typer.Exit()


@app.command()
def init():
    """
    Init
    """
    init_config()
    init_auth()


@app.command()
def upload(
    blog_title: Annotated[
        str, typer.Argument(help="The title of the blog entry.", show_default=False)
    ],
    blog_path: Annotated[
        Path,
        typer.Argument(
            help="The path of the blog entry. (Markdown)", show_default=False
        ),
    ],
    publish: Annotated[
        bool, typer.Option(help="Publish if true.", prompt="Publish draft?")
    ],
    with_images: Annotated[
        bool, typer.Option(help="Upload images if true.", prompt="Upload images?")
    ],
):
    """
    Upload a blog entry to Hatena Blog.
    """
    upload_entry(blog_title, blog_path, with_images, publish)


@app.command()
def update(
    blog_title: Annotated[
        str, typer.Argument(help="The title of the blog entry.", show_default=False)
    ],
    blog_path: Annotated[
        Path, typer.Argument(help="The path of the blog entry.", show_default=False)
    ],
    blog_id: Annotated[int, typer.Argument(help="The id of the blog entry.")],
    publish: Annotated[
        bool, typer.Option(help="Publish if true.", prompt="Publish draft?")
    ],
    with_images: Annotated[
        bool, typer.Option(help="Update images if true.", prompt="Upload images?")
    ],
):
    """
    Update a blog entry at Hatena Blog.
    """
    update_entry(blog_id, blog_title, blog_path, with_images, publish)


@app.command()
def delete(
    blog_id: Annotated[int, typer.Argument(help="The id of the blog entry.")],
    with_images: Annotated[
        bool, typer.Option(help="Delete images if true.", prompt="Delete images?")
    ],
):
    """
    Delete a blog entry at Hatena Blog.
    """
    print(f"This command will delete blog entry {blog_id}.")
    typer.confirm("Continue?", abort=True)
    delete_entry(blog_id, with_images)


config_app = typer.Typer()
app.add_typer(config_app)


@config_app.callback()
def config():
    """
    Display config
    """
    pass


@config_app.command("list")
def config_list():
    """ """
    config = FlatDict(get_config())
    for key, value in config.iteritems():
        print(f"{key}: {value}")


@config_app.command("get")
def config_get(key: Annotated[str, typer.Argument(help="")]):
    """ """
    config = FlatDict(get_config())
    print(f"{key}: {config[key]}")


@config_app.command("set")
def config_set(
    key: Annotated[str, typer.Argument(help="")],
    value: Annotated[str, typer.Argument(help="")],
):
    """ """
    config = FlatDict(get_config())
    config[key] = value
    print(f"{key}: {config[key]}")
    set_config(config.as_dict())


if __name__ == "__main__":
    app()
