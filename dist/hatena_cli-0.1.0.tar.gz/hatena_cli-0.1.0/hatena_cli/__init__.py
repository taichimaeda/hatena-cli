# Sets version for the CLI.
# Read by `poetry` and `version_callback` in `./main.py`.
__version__ = "0.1.0"
