from datetime import datetime, timedelta
from typing import Tuple
import requests
import webbrowser
from urllib import parse
from requests_oauthlib import OAuth1
from rich import print
import typer

from .config import get_config, set_config

_HATENA_SCOPES = ["read_public",
                  "write_public",
                  "read_private",
                  "write_private"]
_HATENA_INITIATE_URL = "https://www.hatena.com/oauth/initiate"
_HATENA_AUTHORIZE_URL = "https://www.hatena.ne.jp/oauth/authorize"
_HATENA_ACCESS_TOKEN_URL = "https://www.hatena.com/oauth/token"


auth_config = get_config()['auth']
_auth = OAuth1(auth_config['api_key'],
               auth_config['api_secret'],
               auth_config['access_token'],
               auth_config['access_secret'])


def init_auth():
    auth_config = get_config()['auth']
    if auth_config['access_token'] != '' or auth_config['access_secret'] != '' or datetime.now() >= auth_config['expires']:
        auth_config['access_token'], auth_config['access_secret'] = \
            get_access_token(
                auth_config['api_key'], auth_config['api_secret'])
        auth_config['expires'] = datetime.now() + timedelta(days=60)
    set_config('auth', auth_config)


def get_access_token(api_key: str, api_secret: str) -> Tuple[str, str]:
    request_token, request_secret = _get_request_token(api_key, api_secret)
    verifier = _get_verifier(request_token)

    print('Obtaining access token...')
    auth = OAuth1(api_key, api_secret, request_token, request_secret,
                  verifier=verifier)
    res = requests.post(_HATENA_ACCESS_TOKEN_URL, auth=auth)
    params = dict(parse.parse_qsl(res.text))
    access_token = params['oauth_token']
    access_secret = params['oauth_token_secret']
    print('Done.')
    return (access_token, access_secret)


def _get_request_token(api_key: str, api_secret: str) -> Tuple[str, str]:
    print('Obtaining request token...')
    auth = OAuth1(api_key, api_secret, callback_uri="oob")
    res = requests.post(
        _HATENA_INITIATE_URL, auth=auth, data={"scope": ",".join(_HATENA_SCOPES)})
    params = dict(parse.parse_qsl(res.text))
    request_token = params['oauth_token']
    request_secret = params['oauth_token_secret']
    print('Done.')
    return (request_token, request_secret)


def _get_verifier(request_token: str) -> str:
    print("Launching web browser for user authentication...")
    webbrowser.open(
        f"{_HATENA_AUTHORIZE_URL}?oauth_token={request_token}")
    verifier = typer.prompt("Enter code")
    print("Done.")
    return verifier


def get_auth() -> OAuth1:
    global _auth
    return _auth
