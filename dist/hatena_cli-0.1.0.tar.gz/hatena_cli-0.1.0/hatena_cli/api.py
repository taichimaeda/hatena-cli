import os
import base64
import re
import requests
from urllib import parse
from pathlib import Path
from requests_oauthlib import OAuth1
from bs4 import BeautifulSoup
from rich import print
import typer

from .config import get_config


_HATENA_BLOG_URL = f"https://blog.hatena.ne.jp/"
_HATENA_FOTOLIFE_POST_URL = "https://f.hatena.ne.jp/atom/post"
_HATENA_FOTOLIFE_EDIT_URL = "https://f.hatena.ne.jp/atom/edit"


def _convert(blog_path: Path):
    print("Converting Markdown to HTML...")
    path_config = get_config()['path']
    os.system(
        f"{path_config['pandoc']} --quiet --standalone --template '{path_config['template']}' \
                 --output '{blog_path.with_suffix('.html')}' '{blog_path}'")
    print("Done.")


def upload_entry(blog_title: str, blog_path: Path, with_images: bool, publish: bool):
    _convert(blog_path)
    auth = auth.get()
    if with_images:
        _upload_images(blog_title, blog_path, auth)
    _upload_html(blog_title, blog_path, publish, auth)


def _upload_images(blog_title: str, blog_path: Path, auth: OAuth1):
    print('Uploading images...')
    image_config = get_config()['image']
    with open(blog_path.with_suffix('.html'), mode="r") as file:
        content = file.read()
        total = len(re.findall(image_config['pattern'], content))

    with typer.progressbar(length=total) as progress:
        def callback(match: re.Match):
            progress.update(1)
            image_path = parse.unquote(match.group(1))
            image_url = _upload_image(blog_title, image_path, auth)
            return image_config['replace'].replace(r'\1', image_url)

        re.sub(image_config['pattern'], callback, content)
    print('Done.')


def _upload_image(blog_title: str, image_path: Path, auth: OAuth1) -> Path:
    with open(image_path, mode="rb") as file:
        content = file.read()
        content = base64.b64encode(content).decode()

    # Maximum length for <dc:subject /> is 24
    res = requests.post(
        _HATENA_FOTOLIFE_POST_URL,
        auth=auth,
        timeout=None,
        headers={"Content-Type": "application/xml"},
        data=f"""\
<?xml version="1.0"?>
<entry xmlns="http://purl.org/atom/ns#">
    <dc:subject>{blog_title[:24]}</dc:subject>
    <title>{blog_title}</title>
    <content mode="base64" type="image/png">{content}</content>
</entry>""")
    if res.status_code != 201:
        print('[red]Error while uploading image.[/red]')
        raise typer.Abort()

    xml = BeautifulSoup(res.text, features="xml")
    url = xml.find("entry").find("hatena:imageurl").text
    return Path(url)


def _upload_html(blog_title: str, blog_path: Path, publish: bool, auth: OAuth1):
    print("Uploading HTML...")
    with open(blog_path.with_suffix('html'), mode="r") as file:
        content = file.read()

    blog_config = get_config()['blog']
    res = requests.post(
        f"{_HATENA_BLOG_URL}/{blog_config['username']}/{blog_config['domain']}/atom/entry",
        auth=auth,
        timeout=None,
        headers={"Content-Type": "application/xml; charset=utf-8"},
        data=f"""\
<?xml version="1.0" encoding="utf-8"?>
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:app="http://www.w3.org/2007/app">
    <title>{blog_title}</title>
    <author><name>name</name></author>
    <content type="text/html"><![CDATA[{content}]]></content>
    <app:control><app:draft>{'no' if publish else 'yes'}</app:draft></app:control>
</entry>""".encode("utf-8"))
    if res.status_code != 201:
        print('[red]Error while uploading HTML.[/red]')
        raise typer.Abort()
    print("Done.")


def update_entry(blog_id: int, blog_title: str, blog_path: Path, with_images: bool, publish: bool):
    _convert(blog_path)
    auth = auth.get()
    if with_images:
        _update_images(blog_id, blog_title, blog_path, auth)
    _update_html(blog_id, blog_title, blog_path, publish, auth)


def _update_images(blog_id: int, blog_title: str, blog_path: Path, auth: OAuth1):
    print('Updating images...')
    _delete_images(blog_id, auth)
    _upload_images(blog_title, blog_path, auth)
    print('Done.')


def _update_html(blog_id: int, blog_title: str, blog_path: Path, publish: bool, auth: OAuth1):
    print("Updating HTML...")
    with open(blog_path.with_suffix('html'), mode="r") as file:
        content = file.read()

    blog_config = get_config['blog']
    res = requests.put(
        f"{_HATENA_BLOG_URL}/{blog_config['username']}/{blog_config['domain']}/atom/entry/{blog_id}",
        auth=auth,
        timeout=None,
        headers={"Content-Type": "application/xml; charset=utf-8"},
        data=f"""\
<?xml version="1.0" encoding="utf-8"?>
<entry xmlns="http://www.w3.org/2005/Atom" xmlns:app="http://www.w3.org/2007/app">
    <title>{blog_title}</title>
    <author><name>name</name></author>
    <content type="text/html"><![CDATA[{content}]]></content>
    <app:control><app:draft>{'no' if publish else 'yes'}</app:draft></app:control>
</entry>""".encode("utf-8"))
    if res.status_code != 200:
        print('[red]Error while updating HTML.[/red]')
        raise typer.Abort()
    print("Done.")


def delete_entry(blog_id: int, with_images: bool):
    auth = auth.get()
    if with_images:
        _delete_images(blog_id, auth)
    _delete_html(blog_id, auth)


def _delete_images(blog_id: int, auth: OAuth1):
    print('Deleting images...')
    blog_config = get_config()['blog']
    res = requests.get(f"{_HATENA_BLOG_URL}/{blog_config['username']}/{blog_config['domain']}/{blog_id}",
                       auth=auth, timeout=None)
    if res.status_code != 200:
        print('[red]Error while downloading HTML.[/red]')
        raise typer.Abort()

    image_config = get_config()['image']
    xml = BeautifulSoup(res.text, features="xml")
    content = xml.find("entry").find("hatena:formatted-content").text
    content = parse.unquote(content)
    total = len(re.findall(image_config['pattern'], content))

    with typer.progressbar(length=total) as progress:
        def callback(match: re.Match):
            progress.update(1)
            image_path = parse.unquote(match.group(1))
            image_id = os.path.splitext(os.path.basename(image_path))[0]
            res = requests.delete(f"{_HATENA_FOTOLIFE_EDIT_URL}/{image_id}",
                                  auth=auth, timeout=None)
            if res.status_code != 200:
                print('[red]Error while deleting image.[/red]')
                raise typer.Abort()

        re.sub(image_config['pattern'], callback, content)
    print('Done.')


def _delete_html(blog_id: int, auth: OAuth1):
    print('Deleting HTML...')
    blog_config = get_config()['blog']
    res = requests.delete(f"{_HATENA_BLOG_URL}/{blog_config['username']}/{blog_config['domain']}/{blog_id}",
                          auth=auth, timeout=None)
    if res.status_code != 200:
        print('[red]Error while deleting HTML.[/red]')
        raise typer.Abort()
    print('Done.')
