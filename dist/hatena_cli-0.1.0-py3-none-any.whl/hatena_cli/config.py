import toml
from flatdict import FlatDict
from pathlib import Path
from datetime import datetime
from rich import print
import typer

_CONFIG_DIR = Path().home() / ".hatena-cli"
_CONFIG_PATH = _CONFIG_DIR / "config.toml"
_TEMPLATE_PATH = _CONFIG_DIR / "template.html"
_PANDOC_PATH = Path("/opt/homebrew/bin/pandoc")
_DEFAULT_CONFIG = {
    "auth": {
        "api_key": "",
        "api_secret": "",
        "access_token": "",
        "access_secret": "",
        "expires": datetime.now(),
    },
    "blog": {
        "username": "",
        "domain": "",
    },
    "image": {
        "pattern": "",
        "replace": "",
    },
    "path": {
        "template": _TEMPLATE_PATH,
        "pandoc": _PANDOC_PATH,
    },
}
_DEFAULT_TEMPLATE = "$body$"

if not _CONFIG_DIR.exists():
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
if not _CONFIG_PATH.exists():
    toml.dump(_DEFAULT_CONFIG, _CONFIG_PATH)
if not _TEMPLATE_PATH.exists():
    with open(_TEMPLATE_PATH, "w") as file:
        file.write(_DEFAULT_TEMPLATE)

_config = FlatDict(toml.load(_CONFIG_PATH))


def init_config():
    for key in _config.iterkeys():
        if key not in ["auth.access_token", "auth.access_secret", "auth.expires"]:
            _config[key] = typer.prompt(key)


def get_config() -> dict:
    global _config
    return _config.as_dict()


def set_config(key: str, config: dict):
    global _config
    check_config()
    _config[key] = FlatDict(config)
    check_config()
    toml.dump(_CONFIG_PATH, _config.as_dict())


def check_config():
    # Check all tables exist.
    for key, value in FlatDict(_DEFAULT_CONFIG).iteritems():
        if key not in _config:
            print(f"[red]`{key}` not found.[/red]")
            typer.Abort()
        if value == "":
            print(f"[red]`{key}` is empty. [/red]")
            typer.Abort()
